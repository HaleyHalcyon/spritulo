FontForge can't write a features.fea file that it can read back later (my brother in Christ you wrote the feature file), so please edit Spritulo.ufo instead of Spritulo.sfd.

Current work needed:

- Reimplement the following OpenType features:

  - case
  - cv02 to cv18
  - ss01 and ss02
  - lnum
  - locl (Bulgarian)
  - locl (Romanian/Moldovan)